<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Keluarga;
use App\Models\KeluargaPart1;
use App\Models\KeluargaPart2;
use App\Models\KeluargaPart3;
use App\Models\KeluargaPart4;
use App\Models\KeluargaPart5;
use App\Models\KeluargaAnggota;
use App\Models\KeluargaFotoRumah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class KuisionerController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | HOME
    |--------------------------------------------------------------------------
    */
    public function index(Request $request)
    {

        /*
        |--------------------------------------------------------------------------
        | JUMLAH RESPONDEN
        |--------------------------------------------------------------------------
        */

        $respondenCount = Keluarga::count();

        /*
        |--------------------------------------------------------------------------
        | JUMLAH BELUM DIDATA
        |--------------------------------------------------------------------------
        */

        $kodeSudahDidata = KeluargaPart1::query()
            ->whereIn('status', ['draft', 'selesai'])
            ->pluck('keluarga_periode_kode')
            ->unique()
            ->toArray();

        $belumDidataCount = Keluarga::whereNotIn(
            'kode',
            $kodeSudahDidata
        )->count();

        /*
        |--------------------------------------------------------------------------
        | JUMLAH DRAFT
        |--------------------------------------------------------------------------
        */

        $draftCount = KeluargaPart1::where('status', 'draft')->count();

        /*
        |--------------------------------------------------------------------------
        | JUMLAH KUISIONER SELESAI
        |--------------------------------------------------------------------------
        */

        $selesaiCount = KeluargaPart1::where('status', 'selesai')->count();

        /*
        |--------------------------------------------------------------------------
        | PENCARIAN DRAFT
        |--------------------------------------------------------------------------
        */

        $search = trim((string) $request->input('search', ''));

        $draftQuery = KeluargaPart1::query()
            ->where('status', 'draft');

        if ($search !== '') {
            $draftQuery->where(function ($query) use ($search) {
                $keyword = '%' . $search . '%';

                $query->where('no_kk', 'like', $keyword)
                    ->orWhere('nik', 'like', $keyword)
                    ->orWhere('nama_kepala_keluarga', 'like', $keyword);
            });
        }

        /*
        |--------------------------------------------------------------------------
        | DATA DRAFT: MAKSIMAL 10 PER HALAMAN
        |--------------------------------------------------------------------------
        */

        $drafts = $draftQuery
            ->orderByDesc('updated_at')
            ->paginate(10, ['*'], 'draft_page')
            ->withQueryString();

        /*
        |--------------------------------------------------------------------------
        | HITUNG PROGRESS SETIAP DRAFT
        |--------------------------------------------------------------------------
        */

        foreach ($drafts as $draft) {
            $draft->completedPart = max(
                0,
                min(5, (int) $draft->current_part - 1)
            );
        }

        /*
        |--------------------------------------------------------------------------
        | DATA SIAP DIAJUKAN
        |--------------------------------------------------------------------------
        */

        $submitCount = $selesaiCount;

        /*
        |--------------------------------------------------------------------------
        | KIRIM DATA KE VIEW
        |--------------------------------------------------------------------------
        */

        return view('admin.kuisioner.index', [
            'page' => 'home',
            'respondenCount' => $respondenCount,
            'belumDidataCount' => $belumDidataCount,
            'draftCount' => $draftCount,
            'selesaiCount' => $selesaiCount,
            'submitCount' => $submitCount,
            'drafts' => $drafts,
            'selesais' => collect(),
            'search' => $search,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | DRAFT
    |--------------------------------------------------------------------------
    */

    public function draft()
    {
        $drafts = KeluargaPart1::where('status', 'draft')
            ->latest('id')
            ->get();

        return view('admin.kuisioner.draft', [
            'drafts' => $drafts,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | SELESAI
    |--------------------------------------------------------------------------
    */

    public function selesai()
    {
        $selesai = KeluargaPart1::where('status', 'selesai')
            ->orderByDesc('updated_at')
            ->get();

        foreach ($selesai as $item) {
            $keluarga = Keluarga::where(
                'kode',
                $item->keluarga_periode_kode
            )->first();

            if (!$keluarga && $item->no_kk) {
                $keluarga = Keluarga::where(
                    'no_kk',
                    $item->no_kk
                )->first();
            }

            $item->keluarga_data = $keluarga;
            $item->rt_rw_display = $keluarga
                ? trim((string) $keluarga->rt . ' / ' . (string) $keluarga->rw, ' /')
                : '-';

            $jumlahAnggotaTambahan = $keluarga
                ? KeluargaAnggota::where('keluarga_kode', $keluarga->kode)->count()
                : 0;

            $item->jumlah_keluarga_display = $item->jml_keluarga !== null
                ? $item->jml_keluarga
                : ($keluarga ? 1 + $jumlahAnggotaTambahan : '-');

            $item->daerah_display = filled($item->daerah)
                ? $item->daerah
                : (filled($item->provinsi) ? $item->provinsi : '-');

            $item->geotagging_display = filled($item->geotangging)
                ? $item->geotangging
                : ($keluarga->geotagging ?? '-');

            $item->kota_kabupaten_display = 'Kota Pasuruan';
        }

        return view('admin.kuisioner.selesai', [
            'selesai' => $selesai,
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | PILIH RESPONDEN
    |--------------------------------------------------------------------------
    */
    public function pilihResponden(Request $request)
    {
        // Rapikan spasi pencarian.
        $search = preg_replace(
            '/\s+/u',
            ' ',
            trim((string) $request->input('search', ''))
        );

        $kataKunci = $search !== ''
            ? preg_split('/\s+/u', $search, -1, PREG_SPLIT_NO_EMPTY)
            : [];

        /*
        |--------------------------------------------------------------------------
        | KODE KELUARGA YANG SUDAH MASUK KUISIONER
        |--------------------------------------------------------------------------
        */
        $kodeSudahDipakai = KeluargaPart1::query()
            ->whereIn('status', ['draft', 'selesai'])
            ->pluck('keluarga_periode_kode')
            ->unique()
            ->toArray();

        /*
        |--------------------------------------------------------------------------
        | RESPONDEN YANG BELUM DIDATA
        |--------------------------------------------------------------------------
        */
        $responden = Keluarga::query()
            ->when(
                !empty($kodeSudahDipakai),
                function ($query) use ($kodeSudahDipakai) {
                    $query->whereNotIn('kode', $kodeSudahDipakai);
                }
            )
            ->when(
                !empty($kataKunci),
                function ($query) use ($kataKunci) {
                    foreach ($kataKunci as $kata) {
                        $query->where(function ($q) use ($kata) {
                            $keyword = '%' . $kata . '%';

                            $q->where('nama_lengkap', 'like', $keyword)
                                ->orWhere('nik', 'like', $keyword)
                                ->orWhere('no_kk', 'like', $keyword);
                        });
                    }
                }
            )
            ->when(
                $search !== '',
                function ($query) use ($search) {
                    $query->orderByRaw(
                        'CASE
                            WHEN nama_lengkap = ? THEN 0
                            WHEN nama_lengkap LIKE ? THEN 1
                            ELSE 2
                        END',
                        [$search, $search . '%']
                    );
                }
            )
            ->orderBy('nama_lengkap')
            ->paginate(10)
            ->withQueryString();

        // AJAX hanya mengembalikan isi tabel dan pagination.
        if ($request->ajax()) {
            return response()->json([
                'html' => view('admin.kuisioner.pilih-responden')
                    ->with(compact('responden', 'search'))
                    ->render(),
            ]);
        }

        // Request biasa tetap menampilkan halaman lengkap.
        return view(
            'admin.kuisioner.pilih-responden',
            compact('responden', 'search')
        );
    }


    /*
    |--------------------------------------------------------------------------
    | PART 1
    |--------------------------------------------------------------------------
    */

    public function part1(Request $request)
    {
        $search = trim($request->get('search', ''));

        /*
        |--------------------------------------------------------------------------
        | AMBIL DATA KELUARGA
        |--------------------------------------------------------------------------
        */

        $query = Keluarga::with('anggota')
            ->orderBy('id');

        if ($search !== '') {
            $query->where(
                'nama_lengkap',
                'like',
                '%' . $search . '%'
            );
        }

        $keluargas = $query
            ->paginate(10)
            ->withQueryString();

        /*
        |--------------------------------------------------------------------------
        | AMBIL STATUS KUESIONER
        |--------------------------------------------------------------------------
        */

        $statusKeluarga = KeluargaPart1::whereIn(
            'keluarga_periode_kode',
            $keluargas->pluck('kode')
        )
            ->orderByDesc('id')
            ->get()
            ->keyBy('keluarga_periode_kode');

        /*
        |--------------------------------------------------------------------------
        | TEMPELKAN STATUS KE KELUARGA
        |--------------------------------------------------------------------------
        */

        foreach ($keluargas as $keluarga) {
            $part1 = $statusKeluarga->get($keluarga->kode);

            if (!$part1) {
                // BELUM PERNAH MULAI
                $keluarga->status_kuesioner = null;
                $keluarga->current_part_kuesioner = 0;
            } else {
                // SUDAH ADA DATA PART 1
                $keluarga->status_kuesioner = $part1->status ?? 'draft';
                $keluarga->current_part_kuesioner = $part1->current_part ?? 1;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | DATA KECAMATAN DAN KELURAHAN
        |--------------------------------------------------------------------------
        */

        $kecamatans = DB::table('kecamatans')
            ->orderBy('deskripsi')
            ->get();

        $kelurahans = DB::table('kelurahans')
            ->orderBy('deskripsi')
            ->get();

        /*
        |--------------------------------------------------------------------------
        | DEFAULT
        |--------------------------------------------------------------------------
        */

        $selectedKeluarga = null;
        $data = null;

        $selectedKecamatan = null;
        $selectedKelurahan = null;
        $anggotaPertama = null;

        /*
        |--------------------------------------------------------------------------
        | JIKA MEMILIH KELUARGA
        |--------------------------------------------------------------------------
        */
        $keluargaAktif = $request->get(
            'keluarga',
            session('selected_keluarga_kode')
        );

        if (!$keluargaAktif) {
            session()->forget([
                'selected_keluarga_kode',
                'draft_keluarga_id',
                'part1_selesai',
                'part2_selesai',
                'part3_selesai',
                'part4_selesai',
                'part5_selesai',
            ]);
        }

        if ($keluargaAktif) {

            $selectedKeluarga = Keluarga::with('anggota')
                ->where(
                    'kode',
                    $keluargaAktif
                )
                ->first();

            if ($selectedKeluarga) {

                $anggotaPertama = $selectedKeluarga->anggota->first();
            
                $data = KeluargaPart1::where(
                    'keluarga_periode_kode',
                    $selectedKeluarga->kode
                )
                    ->where('status', 'draft')
                    ->latest('id')
                    ->first();

                if ($selectedKeluarga->kecamatan_id) {

                    $selectedKecamatan = DB::table('kecamatans')
                        ->where(
                            'kecamatan_id',
                            $selectedKeluarga->kecamatan_id
                        )
                        ->value('deskripsi');
                }

                if ($selectedKeluarga->kelurahan_id) {

                    $selectedKelurahan = DB::table('kelurahans')
                        ->where(
                            'kelurahan_id',
                            $selectedKeluarga->kelurahan_id
                        )
                        ->value('deskripsi');
                }

                session([
                    'selected_keluarga_kode' =>
                        $selectedKeluarga->kode,
                ]);
            }
        }

        return view('admin.kuisioner.part1', [

            'keluargas' => $keluargas,

            'selectedKeluarga' => $selectedKeluarga,

            'data' => $data,

            'kecamatans' => $kecamatans,

            'kelurahans' => $kelurahans,

            'selectedKecamatan' => $selectedKecamatan,

            'selectedKelurahan' => $selectedKelurahan,

            'anggotaPertama' => $anggotaPertama,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | SIMPAN PART 1
    |--------------------------------------------------------------------------
    */

    public function storePart1(Request $request)
    {
        $validated = $request->validate([
            'nik' => [
                'nullable',
                'string',
                'max:255',
            ],

            'nama_kepala_keluarga' => [
                'nullable',
                'string',
                'max:255',
            ],

            'status_keluarga' => [
                'nullable',
                'string',
                'max:255',
            ],

            'nomor_induk_keluarga' => [
                'nullable',
                'string',
                'max:255',
            ],

            'no_kk' => [
                'nullable',
                'string',
                'max:255',
            ],

            'jml_keluarga' => [
                'nullable',
                'string',
                'max:255',
            ],

            'provinsi' => [
                'nullable',
                'string',
                'max:255',
            ],

            'daerah' => [
                'nullable',
                'string',
                'max:255',
            ],

            'kecamatan' => [
                'nullable',
                'string',
                'max:255',
            ],

            'kelurahan' => [
                'nullable',
                'string',
                'max:255',
            ],

            'kode_pos' => [
                'nullable',
                'string',
                'max:16',
            ],

            'rt_rw' => [
                'nullable',
                'string',
                'max:255',
            ],

            'alamat_lengkap' => [
                'nullable',
                'string',
                'max:255',
            ],

            'jalan_rumah' => [
                'nullable',
                'string',
                'max:255',
            ],

            'nomor_rumah' => [
                'nullable',
                'string',
                'max:255',
            ],

            'is_alamat_sesuai' => [
                'nullable',
                'boolean',
            ],

            'alasan_tidak_sesuai' => [
                'nullable',
                'string',
                'max:1000',
            ],

            'geotangging' => [
                'nullable',
                'string',
                'max:255',
            ],

            'keluarga_kode' => [
                'nullable',
                'string',
                'max:255',
            ],

            // TAMBAHAN UNTUK TOMBOL
            'action' => [
                'required',
                'in:draft,next',
            ],
        ]);

        $user = auth()->user()->name ?? 'admin';

        /*
        |--------------------------------------------------------------------------
        | TENTUKAN KODE KELUARGA
        |--------------------------------------------------------------------------
        */

        $keluargaKode =
            $validated['keluarga_kode']
            ?? session('selected_keluarga_kode');

        if (!$keluargaKode) {
            return back()
                ->withInput()
                ->with(
                    'error',
                    'Kode keluarga tidak ditemukan. Silakan pilih keluarga terlebih dahulu.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | CARI DRAFT MILIK KELUARGA
        |--------------------------------------------------------------------------
        */

        $draft = KeluargaPart1::where(
            'keluarga_periode_kode',
            $keluargaKode
        )
            ->where('status', 'draft')
            ->latest('id')
            ->first();

        /*
        |--------------------------------------------------------------------------
        | JIKA BELUM ADA DRAFT
        |--------------------------------------------------------------------------
        */

        if (!$draft) {
            $draft = new KeluargaPart1();

            $draft->status = 'draft';
            $draft->current_part = 1;
            $draft->created_by = $user;
        }

        /*
        |--------------------------------------------------------------------------
        | DATA DASAR
        |--------------------------------------------------------------------------
        */

        $draft->nik =
            $validated['nik'] ?? null;

        $draft->nama_kepala_keluarga =
            $validated['nama_kepala_keluarga'] ?? null;

        $draft->no_kk =
            $validated['no_kk'] ?? null;

        $draft->jml_keluarga =
            $validated['jml_keluarga'] ?? null;

        $draft->provinsi =
            $validated['provinsi'] ?? null;

        $draft->daerah =
            $validated['daerah'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | KECAMATAN
        |--------------------------------------------------------------------------
        */

        $draft->kecamatan =
            $validated['kecamatan'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | KELURAHAN
        |--------------------------------------------------------------------------
        */

        $draft->kelurahan =
            $validated['kelurahan'] ?? null;

        $draft->kode_pos =
            $validated['kode_pos'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | ALAMAT LENGKAP
        |--------------------------------------------------------------------------
        | Simpan alamat persis seperti yang dikirim dari form.
        | RT/RW tetap disimpan pada kolom rt_rw, tidak digabungkan ke alamat.
        */

        $draft->alamat_lengkap = trim(
            $validated['alamat_lengkap'] ?? ''
        );

        /*
        |--------------------------------------------------------------------------
        | JALAN DAN NOMOR RUMAH
        |--------------------------------------------------------------------------
        */

        $draft->jalan_rumah =
            $validated['jalan_rumah'] ?? null;

        $draft->nomor_rumah =
            $validated['nomor_rumah'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | ALAMAT SESUAI
        |--------------------------------------------------------------------------
        */

        $draft->is_alamat_sesuai = 
            $validated['is_alamat_sesuai'] ?? null;

        $draft->alasan_tidak_sesuai = 
            $validated['alasan_tidak_sesuai'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | GEOTAGGING
        |--------------------------------------------------------------------------
        */

        $draft->geotangging =
            $validated['geotangging'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | HUBUNGKAN DENGAN KELUARGA
        |--------------------------------------------------------------------------
        */

        $draft->keluarga_periode_kode =
            $keluargaKode;

        /*
        |--------------------------------------------------------------------------
        | STATUS
        |--------------------------------------------------------------------------
        */

        $draft->status = 'draft';

        /*
        |--------------------------------------------------------------------------
        | TENTUKAN PART BERDASARKAN TOMBOL
        |--------------------------------------------------------------------------
        */

        if ($validated['action'] === 'draft') {

            // Tetap di Part 1
            $draft->current_part = 1;

        } else {

            // Lanjut ke Part 2
            $draft->current_part = 2;
        }

        /*
        |--------------------------------------------------------------------------
        | UPDATED BY
        |--------------------------------------------------------------------------
        */

        $draft->updated_by =
            $user;

        /*
        |--------------------------------------------------------------------------
        | SIMPAN
        |--------------------------------------------------------------------------
        */

        $draft->save();

        /*
        |--------------------------------------------------------------------------
        | SIMPAN DRAFT AKTIF KE SESSION
        |--------------------------------------------------------------------------
        */

        session([
            'draft_keluarga_id' =>
                $draft->id,

            'selected_keluarga_kode' =>
                $keluargaKode,

            'part1_selesai' =>
                false,

            'part2_selesai' =>
                false,

            'part3_selesai' =>
                false,

            'part4_selesai' =>
                false,

            'part5_selesai' =>
                false,
        ]);

        /*
        |--------------------------------------------------------------------------
        | JIKA KLIK DRAFT
        |--------------------------------------------------------------------------
        */

        if ($validated['action'] === 'draft') {

            return redirect()
                ->route('kuisioner.index')
                ->with(
                    'success',
                    'Data Part 1 berhasil disimpan sebagai draft.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | JIKA KLIK SIMPAN & LANJUTKAN
        |--------------------------------------------------------------------------
        */

        return redirect()
            ->route('kuisioner.part2')
            ->with(
                'success',
                'Data Part 1 berhasil disimpan. Silakan lanjut ke Part 2.'
            );
    }

    /*
    |--------------------------------------------------------------------------
    | PART 2
    |--------------------------------------------------------------------------
    */

    public function part2()
    {
        $keluargaKode = session('selected_keluarga_kode');

        if (!$keluargaKode) {
            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'warning',
                    'Silakan pilih keluarga dan selesaikan Part 1 terlebih dahulu.'
                );
        }

        $draftId = session('draft_keluarga_id');

        if (!$draftId) {
            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'warning',
                    'Silakan lengkapi dan simpan Part 1 terlebih dahulu.'
                );
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where(
                'keluarga_periode_kode',
                $keluargaKode
            )
            ->where('status', 'draft')
            ->first();

        if (!$draft) {

            session()->forget([
                'draft_keluarga_id',
                'selected_keluarga_kode',
                'part1_selesai',
                'part2_selesai',
                'part3_selesai',
                'part4_selesai',
                'part5_selesai',
            ]);

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'warning',
                    'Silakan pilih keluarga dan selesaikan Part 1 terlebih dahulu.'
                );
        }

        if ((int) $draft->current_part < 2) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'warning',
                    'Silakan lengkapi dan simpan Part 1 terlebih dahulu.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | AMBIL DATA PART 2
        |--------------------------------------------------------------------------
        */

        $dataPart2 = null;

        if ($draft->keluarga_periode_kode) {

            $dataPart2 = KeluargaPart2::where(
                'keluarga_periode_kode',
                $draft->keluarga_periode_kode
            )->first();
        }

        return view('admin.kuisioner.part2', [
            'dataPart2' => $dataPart2,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | SIMPAN PART 2
    |--------------------------------------------------------------------------
    */

    public function storePart2(Request $request)
    {
        $draftId = session('draft_keluarga_id');

        if (!$draftId) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'warning',
                    'Silakan lengkapi dan simpan Part 1 terlebih dahulu.'
                );
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where('status', 'draft')
            ->first();

        if (!$draft) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'warning',
                    'Draft kuisioner tidak ditemukan.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | VALIDASI
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate([

            'jenis_bangunan' => [
                'nullable',
                'string',
                'max:255',
            ],

            'keluarga_lain' => [
                'nullable',
                'in:Ya,Tidak',
            ],

            'jumlah_keluarga_lain' => [
                'nullable',
                'numeric',
                'min:1',
            ],

            'jumlah_orang' => [
                'nullable',
                'numeric',
                'min:1',
            ],

            'status_kepemilikan' => [
                'nullable',
                'string',
                'max:255',
            ],

            'bukti_kepemilikan' => [
                'nullable',
                'string',
                'max:255',
            ],

            'sewa_bulanan' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'perkiraan_sewa' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'status_kepemilikan_lainnya' => [
                'nullable',
                'string',
                'max:255',
            ],

            'luas_lantai' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'jenis_lantai' => [
                'nullable',
                'string',
                'max:255',
            ],

            'kondisi_lantai' => [
                'nullable',
                'string',
                'max:255',
            ],

            'jenis_dinding' => [
                'nullable',
                'string',
                'max:255',
            ],

            'kondisi_dinding' => [
                'nullable',
                'string',
                'max:255',
            ],

            'jenis_atap' => [
                'nullable',
                'string',
                'max:255',
            ],

            'kondisi_atap' => [
                'nullable',
                'in:Baik,Rusak Ringan,Rusak Sedang,Rusak Berat',
            ],

            'fasilitas_bab' => [
                'nullable',
                'string',
                'max:255',
            ],

            'jenis_toilet' => [
                'nullable',
                'string',
                'max:255',
            ],

            'sumber_air_minum' => [
                'nullable',
                'string',
                'max:255',
            ],

            'sumber_penerangan' => [
                'nullable',
                'string',
                'max:255',
            ],

            'daya_listrik' => [
                'nullable',
                'string',
                'max:255',
            ],

            'id_pelanggan_pln' => [
                'nullable',
                'string',
                'max:255',
            ],

            'jumlah_meteran' => [
                'nullable',
                'numeric',
                'min:1',
            ],

            'action' => [
                'required',
                'in:draft,next',
            ],
        ]);

        $user = auth()->user()->name ?? 'admin';

        /*
        |--------------------------------------------------------------------------
        | KODE KELUARGA
        |--------------------------------------------------------------------------
        */

        $keluargaKode = $draft->keluarga_periode_kode;

        if (!$keluargaKode) {
            $keluargaKode = session('selected_keluarga_kode');
        }

        if (!$keluargaKode) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'warning',
                    'Kode keluarga tidak ditemukan. Silakan pilih keluarga kembali.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | KONVERSI KONDISI ATAP
        |--------------------------------------------------------------------------
        */

        $kondisiAtap = null;

        if (!empty($validated['kondisi_atap'])) {

            $kondisiAtap = match ($validated['kondisi_atap']) {

                'Baik' => 1,

                'Rusak Ringan' => 2,

                'Rusak Sedang' => 3,

                'Rusak Berat' => 4,

                default => null,
            };
        }

        /*
        |--------------------------------------------------------------------------
        | STATUS KEPEMILIKAN
        |--------------------------------------------------------------------------
        */

        $kepemilikan =
            $validated['status_kepemilikan'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | HARGA SEWA
        |--------------------------------------------------------------------------
        */

        $hargaSewa = null;

        if ($kepemilikan === 'Kontrak/Sewa') {

            $hargaSewa =
                $validated['sewa_bulanan'] ?? null;

        } elseif ($kepemilikan === 'Bebas Sewa') {

            $hargaSewa =
                $validated['perkiraan_sewa'] ?? null;
        }

        /*
        |--------------------------------------------------------------------------
        | SIMPAN / UPDATE
        |--------------------------------------------------------------------------
        */

        DB::transaction(function () use (
            $validated,
            $keluargaKode,
            $draft,
            $user,
            $kondisiAtap,
            $kepemilikan,
            $hargaSewa
        ) {

            $data = [

                'keluarga_periode_kode' =>
                    $keluargaKode,

                'jenis_bangungan' =>
                    $validated['jenis_bangunan'] ?? null,

                'is_keluarga_lain' =>
                    isset($validated['keluarga_lain'])
                        ? (
                            $validated['keluarga_lain'] === 'Ya'
                                ? 1
                                : 0
                        )
                        : null,

                'jml_keluarga_lain' =>
                    $validated['jumlah_keluarga_lain'] ?? null,

                'total_penghuni' =>
                    $validated['jumlah_orang'] ?? null,

                'kepemilikan_bangunan' =>
                    $kepemilikan,

                'bukti_kepemilikan' =>
                    $validated['bukti_kepemilikan'] ?? null,

                'harga_sewa_kontrak' =>
                    $hargaSewa,

                'luas_lantai' =>
                    $validated['luas_lantai'] ?? null,

                'jenis_lantai' =>
                    $validated['jenis_lantai'] ?? null,

                'kondisi_lantai' =>
                    $validated['kondisi_lantai'] ?? null,

                'jenis_dinding' =>
                    $validated['jenis_dinding'] ?? null,

                'kondisi_dinding' =>
                    $validated['kondisi_dinding'] ?? null,

                'jenis_atap' =>
                    $validated['jenis_atap'] ?? null,

                'kondisi_atap' =>
                    $kondisiAtap,

                'fasilitas_bab' =>
                    $validated['fasilitas_bab'] ?? null,

                'jenis_kloset' =>
                    $validated['jenis_toilet'] ?? null,

                'sumber_minum' =>
                    $validated['sumber_air_minum'] ?? null,

                'sumber_penerangan' =>
                    $validated['sumber_penerangan'] ?? null,

                'daya_listrik' =>
                    $validated['daya_listrik'] ?? null,

                'idpel_pln' =>
                    $validated['id_pelanggan_pln'] ?? null,

                'jml_meteran' =>
                    $validated['jumlah_meteran'] ?? null,

                'updated_by' =>
                    $user,

                'updated_at' =>
                    now(),
            ];

            $part2 = KeluargaPart2::where(
                'keluarga_periode_kode',
                $keluargaKode
            )->first();

            if (!$part2) {

                $data['created_by'] = $user;
                $data['created_at'] = now();

                KeluargaPart2::create($data);

            } else {

                $part2->update($data);
            }

            /*
            |--------------------------------------------------------------------------
            | UPDATE PROGRESS
            |--------------------------------------------------------------------------
            */

            $draft->update([

                'current_part' =>
                    $validated['action'] === 'draft' ? 2 : 3,

                'updated_by' => $user,

            ]);
        });

        /*
        |--------------------------------------------------------------------------
        | SESSION
        |--------------------------------------------------------------------------
        */

        session([
            'draft_keluarga_id' =>
                $draft->id,

            'part1_selesai' =>
                true,

            'part2_selesai' =>
                $validated['action'] === 'next',

            'part3_selesai' =>
                false,

            'part4_selesai' =>
                false,

            'part5_selesai' =>
                false,
        ]);

        if ($validated['action'] === 'draft') {
            return redirect()
                ->route('kuisioner.index')
                ->with(
                    'success',
                    'Data Part 2 berhasil disimpan sebagai draft.'
                );
        }

        return redirect()
            ->route('kuisioner.part3')
            ->with(
                'success',
                'Data Part 2 berhasil disimpan. Silakan lanjut ke Part 3.'
            );
    }

    /*
    |--------------------------------------------------------------------------
    | PART 3
    |--------------------------------------------------------------------------
    */

    public function part3()
    {
        $keluargaKode = session('selected_keluarga_kode');

        if (!$keluargaKode) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draftId = session('draft_keluarga_id');

        if (!$draftId) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where(
                'keluarga_periode_kode',
                $keluargaKode
            )
            ->where('status', 'draft')
            ->first();

        if (!$draft) {

            session()->forget([
                'draft_keluarga_id',
                'selected_keluarga_kode',
                'part1_selesai',
                'part2_selesai',
                'part3_selesai',
                'part4_selesai',
                'part5_selesai',
            ]);

            return redirect()
                ->route('kuisioner.part1');
        }

        if ((int) $draft->current_part < 3) {

            return redirect()
                ->route('kuisioner.part1');
        }

        $dataPart3 = KeluargaPart3::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )->first();

        return view(
            'admin.kuisioner.part3',
            compact(
                'draft',
                'dataPart3'
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | SIMPAN PART 3
    |--------------------------------------------------------------------------
    */

    
    public function storePart3(Request $request)
    {
        $draftId = session('draft_keluarga_id');

        if (!$draftId) {
            return redirect()
                ->route('kuisioner.part1')
                ->with('error', 'Silakan pilih keluarga terlebih dahulu.');
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where('status', 'draft')
            ->first();

        if (!$draft) {
            return redirect()
                ->route('kuisioner.part1')
                ->with('error', 'Data draft keluarga tidak ditemukan.');
        }

        if ((int) $draft->current_part < 3) {
            return redirect()
                ->route('kuisioner.part2')
                ->with('error', 'Silakan selesaikan Part 2 terlebih dahulu.');
        }

        /*
        |--------------------------------------------------------------------------
        | UBAH NOMINAL BERTITIK MENJADI ANGKA
        |--------------------------------------------------------------------------
        */

        $kolomNominal = [
            'pengeluaran_listrik_bulanan',
            'pengeluaran_pulsa_bulanan',
            'pengeluaran_internet_bulanan',
            'pengeluaran_makan_mingguan',
            'pengeluaran_nonmakan_bulanan',
            'pengeluaran_nonmakan_tahunan',
            'total_pendapatan_kerja',
            'total_pendapatan_usaha',
            'total_pendapatan_lainnya',
        ];

        foreach ($kolomNominal as $kolom) {
            $nilai = $request->input($kolom);

            if ($nilai !== null && $nilai !== '') {
                $request->merge([
                    $kolom => str_replace('.', '', (string) $nilai),
                ]);
            } else {
                $request->merge([
                    $kolom => null,
                ]);
            }
        }

        /*
        |--------------------------------------------------------------------------
        | VALIDASI
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate([
            'pengeluaran_listrik_bulanan' => ['nullable', 'numeric', 'min:0'],
            'pengeluaran_pulsa_bulanan' => ['nullable', 'numeric', 'min:0'],
            'pengeluaran_internet_bulanan' => ['nullable', 'numeric', 'min:0'],
            'pengeluaran_makan_mingguan' => ['nullable', 'numeric', 'min:0'],
            'pengeluaran_nonmakan_bulanan' => ['nullable', 'numeric', 'min:0'],
            'pengeluaran_nonmakan_tahunan' => ['nullable', 'numeric', 'min:0'],

            'pendapatan_pekerjaan' => ['nullable', 'in:Ada,Tidak'],
            'total_pendapatan_kerja' => ['nullable', 'numeric', 'min:0'],

            'total_pendapatan_usaha' => ['nullable', 'numeric', 'min:0'],

            'pendapatan_lainnya' => ['nullable', 'in:Ada,Tidak'],
            'total_pendapatan_lainnya' => ['nullable', 'numeric', 'min:0'],

            'action' => ['required', 'in:draft,next'],
        ]);

        $keluargaKode = $draft->keluarga_periode_kode
            ?: session('selected_keluarga_kode');

        if (!$keluargaKode) {
            return back()
                ->withInput()
                ->with('error', 'Kode keluarga tidak ditemukan.');
        }

        DB::beginTransaction();

        try {
            $user = auth()->user()->username
                ?? auth()->user()->name
                ?? 'admin';

            $data = [
                'keluarga_periode_kode' => $keluargaKode,

                'pengeluaran_listrik_bulanan' =>
                    $validated['pengeluaran_listrik_bulanan'] ?? null,

                'pengeluaran_pulsa_bulanan' =>
                    $validated['pengeluaran_pulsa_bulanan'] ?? null,

                'pengeluaran_internet_bulanan' =>
                    $validated['pengeluaran_internet_bulanan'] ?? null,

                'pengeluaran_makan_mingguan' =>
                    $validated['pengeluaran_makan_mingguan'] ?? null,

                'pengeluaran_nonmakan_bulanan' =>
                    $validated['pengeluaran_nonmakan_bulanan'] ?? null,

                'pengeluaran_nonmakan_tahunan' =>
                    $validated['pengeluaran_nonmakan_tahunan'] ?? null,

                'pendapatan_pekerjaan' =>
                    $validated['pendapatan_pekerjaan'] ?? null,

                'total_pendapatan_kerja' =>
                    ($validated['pendapatan_pekerjaan'] ?? null) === 'Tidak'
                        ? null
                        : ($validated['total_pendapatan_kerja'] ?? null),

                'total_pendapatan_usaha' =>
                    $validated['total_pendapatan_usaha'] ?? null,

                'pendapatan_lainnya' =>
                    $validated['pendapatan_lainnya'] ?? null,

                'total_pendapatan_lainnya' =>
                    ($validated['pendapatan_lainnya'] ?? null) === 'Tidak'
                        ? null
                        : ($validated['total_pendapatan_lainnya'] ?? null),

                'updated_by' => $user,
                'updated_at' => now(),
            ];

            $dataPart3 = KeluargaPart3::where(
                'keluarga_periode_kode',
                $keluargaKode
            )->first();

            if ($dataPart3) {
                $dataPart3->update($data);
            } else {
                $data['created_by'] = $user;
                $data['created_at'] = now();

                KeluargaPart3::create($data);
            }

            /*
            |--------------------------------------------------------------------------
            | PERBARUI PROGRES DRAFT
            |--------------------------------------------------------------------------
            */

            $draft->current_part =
                $validated['action'] === 'draft' ? 3 : 4;

            $draft->updated_by = $user;
            $draft->save();

            session([
                'draft_keluarga_id' => $draft->id,
                'selected_keluarga_kode' => $keluargaKode,
                'part3_selesai' => $validated['action'] === 'next',
                'part4_selesai' => false,
                'part5_selesai' => false,
            ]);

            DB::commit();

            if ($validated['action'] === 'draft') {
                return redirect()
                    ->route('kuisioner.index')
                    ->with(
                        'success',
                        'Data Part 3 berhasil disimpan sebagai draft.'
                    );
            }

            return redirect()
                ->route('kuisioner.part4')
                ->with('success', 'Data Part 3 berhasil disimpan.');

        } catch (\Throwable $e) {
            DB::rollBack();

            report($e);

            return back()
                ->withInput()
                ->with(
                    'error',
                    'Data Part 3 gagal disimpan. Silakan periksa kembali data dan struktur tabel.'
                );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PART 4
    |--------------------------------------------------------------------------
    */

    public function part4()
    {
        $keluargaKode = session('selected_keluarga_kode');
        $draftId = session('draft_keluarga_id');

        if (!$keluargaKode || !$draftId) {
            return redirect()->route('kuisioner.part1');
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where('keluarga_periode_kode', $keluargaKode)
            ->where('status', 'draft')
            ->first();

        if (!$draft) {
            return redirect()->route('kuisioner.part1');
        }

        if ((int) $draft->current_part < 4) {
            return redirect()->route('kuisioner.part1');
        }

        $dataPart4 = KeluargaPart4::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )->get();

        $dataPart4Map = $dataPart4->keyBy('aset_keluarga');

        return view('admin.kuisioner.part4', compact(
            'draft',
            'dataPart4',
            'dataPart4Map'
        ));
    }

    /*
    |--------------------------------------------------------------------------
    | SIMPAN PART 4
    |--------------------------------------------------------------------------
    */

    public function storePart4(Request $request)
    {
        $draftId = session('draft_keluarga_id');

        if (!$draftId) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'error',
                    'Silakan pilih keluarga terlebih dahulu.'
                );
        }

        
        $keluargaKode = session('selected_keluarga_kode');

        $draft = KeluargaPart1::where('id', $draftId)
            ->where('status', 'draft')
            ->when($keluargaKode, function ($query) use ($keluargaKode) {
                $query->where('keluarga_periode_kode', $keluargaKode);
            })
            ->first();


        if (!$draft) {

            session()->forget([
                'draft_keluarga_id',
            ]);

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'error',
                    'Data draft keluarga tidak ditemukan.'
                );
        }

        if ((int) $draft->current_part < 4) {

            return redirect()
                ->route('kuisioner.part3')
                ->with(
                    'error',
                    'Silakan selesaikan Part 3 terlebih dahulu.'
                );
        }

        $request->validate([

            'aset' =>
                ['required', 'array'],

            'aset.*.punya' =>
                ['required', 'in:0,1'],

            'aset.*.jumlah' =>
                ['nullable', 'integer', 'min:0'],

            'action' =>
                ['required', 'in:draft,next'],
        ]);

        $keluargaKode = $draft->keluarga_periode_kode;

        if (!$keluargaKode) {

            return back()
                ->withInput()
                ->with(
                    'error',
                    'Kode keluarga tidak ditemukan.'
                );
        }

        DB::beginTransaction();

        try {

            $asetList = [

                'Tabung Gas 3 KG',

                'Tabung Gas 5,5 KG atau Lebih',

                'Lemari Es/Kulkas',

                'AC (Air Conditioner)',

                'Emas/Perhiasan',

                'Komputer/Laptop/Tablet',

                'Sepeda Motor',

                'Mobil',

                'Rumah/Bangunan (selain yang ditempati)',

                'Lahan Lainnya',
            ];

            foreach ($asetList as $aset) {

                $data = $request->input(
                    'aset.' . md5($aset),
                    []
                );

                $punya = isset($data['punya'])
                    ? (int) $data['punya']
                    : 0;

                $jumlah = $punya === 1
                    ? ($data['jumlah'] ?? 0)
                    : 0;

                $existing = KeluargaPart4::where(
                    'keluarga_periode_kode',
                    $keluargaKode
                )
                    ->where(
                        'aset_keluarga',
                        $aset
                    )
                    ->first();

                $saveData = [

                    'keluarga_periode_kode' =>
                        $keluargaKode,

                    'aset_keluarga' =>
                        $aset,

                    'is_punya_aset' =>
                        $punya,

                    'jml_aset' =>
                        $jumlah,

                    'updated_by' =>
                        auth()->user()->username ?? 'admin',

                    'updated_at' =>
                        now(),
                ];

                if ($existing) {

                    $existing->update($saveData);

                } else {

                    $saveData['created_by'] =
                        auth()->user()->username ?? 'admin';

                    $saveData['created_at'] =
                        now();

                    KeluargaPart4::create($saveData);
                }
            }

            /*
            |--------------------------------------------------------------------------
            | UPDATE PROGRESS
            |--------------------------------------------------------------------------
            */

            $draft->current_part =
                $request->action === 'draft' ? 4 : 5;

            $draft->updated_by =
                auth()->user()->username ?? 'admin';

            $draft->save();

            session([
                'part4_selesai' => $request->action === 'next',
                'part5_selesai' => false,
            ]);

            DB::commit();

            if ($request->action === 'draft') {
                return redirect()
                    ->route('kuisioner.index')
                    ->with(
                        'success',
                        'Data Part 4 berhasil disimpan sebagai draft.'
                    );
            }

            return redirect()
                ->route('kuisioner.part5')
                ->with(
                    'success',
                    'Data Part 4 berhasil disimpan.'
                );

        } catch (\Throwable $e) {

            DB::rollBack();

            return back()
                ->withInput()
                ->with(
                    'error',
                    'Data Part 4 gagal disimpan: ' .
                    $e->getMessage()
                );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PART 5
    |--------------------------------------------------------------------------
    */

    public function part5(Request $request)
    {
        $keluargaKode = session('selected_keluarga_kode');

        if (!$keluargaKode) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draftId = session('draft_keluarga_id');

        if (!$draftId) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where(
                'keluarga_periode_kode',
                $keluargaKode
            )
            ->where('status', 'draft')
            ->first();

        if (!$draft) {

            session()->forget([
                'draft_keluarga_id',
                'selected_keluarga_kode',
                'part1_selesai',
                'part2_selesai',
                'part3_selesai',
                'part4_selesai',
                'part5_selesai',
            ]);

            return redirect()
                ->route('kuisioner.part1');
        }

        if ((int) $draft->current_part < 5) {
            $draft->current_part = 5;
            $draft->save();
        }

        /*
        |--------------------------------------------------------------------------
        | AMBIL SELURUH ANGGOTA KELUARGA
        |--------------------------------------------------------------------------
        */

        $anggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )
            ->orderBy('id')
            ->get();

        /*
        |--------------------------------------------------------------------------
        | AMBIL JAWABAN PART 5
        |--------------------------------------------------------------------------
        */

        
        $dataPart5 = KeluargaPart5::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )
            ->get()
            ->keyBy('keluarga_anggota_kode');

        /*
        |--------------------------------------------------------------------------
        | CEK KELENGKAPAN SEMUA ANGGOTA
        |--------------------------------------------------------------------------
        */

        $jumlahAnggota = $anggota->count();

        $statusPart5 = [];

        foreach ($anggota as $item) {
            $data = $dataPart5->get($item->kode);

            $statusPart5[$item->kode] = $data
                ? $this->part5DataLengkap($data)
                : false;
        }

        $jumlahSelesai = count(array_filter($statusPart5));

        $semuaAnggotaSelesai = $jumlahAnggota > 0
            && $jumlahSelesai === $jumlahAnggota;

        return view(
            'admin.kuisioner.part5',
            compact(
                'draft',
                'anggota',
                'dataPart5',
                'statusPart5',
                'jumlahAnggota',
                'jumlahSelesai',
                'semuaAnggotaSelesai'
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PART 5 ANGGOTA
    |--------------------------------------------------------------------------
    */

    public function part5Anggota($kode)
    {
        $keluargaKode = session('selected_keluarga_kode');

        if (!$keluargaKode) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draftId = session('draft_keluarga_id');

        if (!$draftId) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where(
                'keluarga_periode_kode',
                $keluargaKode
            )
            ->where('status', 'draft')
            ->first();

        if (!$draft) {

            session()->forget([
                'draft_keluarga_id',
                'selected_keluarga_kode',
                'part1_selesai',
                'part2_selesai',
                'part3_selesai',
                'part4_selesai',
                'part5_selesai',
            ]);

            return redirect()
                ->route('kuisioner.part1');
        }

        if ((int) $draft->current_part < 5) {

            return redirect()
                ->route('kuisioner.part1');
        }

        /*
        |--------------------------------------------------------------------------
        | PASTIKAN ANGGOTA MILIK KELUARGA
        |--------------------------------------------------------------------------
        */

        $anggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )
            ->where(
                'kode',
                $kode
            )
            ->first();

        if (!$anggota) {

            return redirect()
                ->route('kuisioner.part5')
                ->with(
                    'error',
                    'Anggota keluarga tidak ditemukan.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | AMBIL DATA YANG SUDAH DISIMPAN
        |--------------------------------------------------------------------------
        */

        $dataPart5 = KeluargaPart5::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )
            ->where(
                'keluarga_anggota_kode',
                $anggota->kode
            )
            ->first();

        return view(
            'admin.kuisioner.part5-anggota',
            compact(
                'draft',
                'anggota',
                'dataPart5'
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | SIMPAN PART 5 ANGGOTA
    |--------------------------------------------------------------------------
    */

    public function storePart5Anggota(
        Request $request,
        $kode
    ) {
        $draftId =
            session('draft_keluarga_id');

        if (!$draftId) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'error',
                    'Silakan mulai pengisian kuisioner terlebih dahulu.'
                );
        }

        $draft =
            KeluargaPart1::find($draftId);

        if (!$draft) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'error',
                    'Data keluarga tidak ditemukan.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | CARI ANGGOTA
        |--------------------------------------------------------------------------
        */

        $anggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )
            ->where(
                'kode',
                $kode
            )
            ->first();

        if (!$anggota) {

            return redirect()
                ->route('kuisioner.part5')
                ->with(
                    'error',
                    'Anggota keluarga tidak ditemukan.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | VALIDASI
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate([

            'keberadaan' =>
                'required|string|max:255',

            'no_hp' =>
                'nullable|string|max:16',

            'jenis_kelamin' =>
                'required|string|max:16',

            'tanggal_lahir' =>
                'nullable|date',

            'status_perkawinan' =>
                'required|string|max:255',

            'status_sekolah' =>
                'required|string|max:255',

            
            'ijazah_tertinggi' =>
                'required|string|max:255',

            'ijazah_lainnya' => [
                'nullable',
                'required_if:ijazah_tertinggi,Lainnya',
                'string',
                'max:255',
            ],


            'pekerjaan_utama' =>
                'required|string|max:255',

            'pekerjaan_lainnya' => [
                'nullable',
                'required_if:pekerjaan_utama,Lainnya',
                'string',
                'max:255',
            ],

            'status_pekerjaan' =>
                'required_unless:pekerjaan_utama,Tidak Bekerja|string|max:255',

            'kepemilikan_rekening' =>
                'required|string|max:255',

            'is_disabilitas_fisik' =>
                'required|in:0,1',

            'is_disabilitas_mental' =>
                'required|in:0,1',

            'is_disabilitas_intelektual' =>
                'required|in:0,1',

            'is_disabilitas_netra' =>
                'required|in:0,1',

            'is_disabilitas_rungu' =>
                'required|in:0,1',

            'is_disabilitas_wicara' =>
                'required|in:0,1',

            'keluhan_kesehatan' => [
            'required',
            'array',
            'min:1',
        ],

        'keluhan_kesehatan.*' => [
            'required',
            'string',
            'max:255',
        ],
        ]);

        /*
        |--------------------------------------------------------------------------
        | DATA
        |--------------------------------------------------------------------------
        */

        $data = [

            'keluarga_periode_kode' =>
                $draft->keluarga_periode_kode,

            'keluarga_anggota_kode' =>
                $anggota->kode,

            'keberadaan' =>
                $validated['keberadaan'],

            'no_hp' =>
                $validated['no_hp'] ?? null,

            'jenis_kelamin' =>
                $validated['jenis_kelamin'],

            'tanggal_lahir' =>
                $validated['tanggal_lahir'] ?? null,

            'status_perkawinan' =>
                $validated['status_perkawinan'],

            'status_sekolah' =>
                $validated['status_sekolah'],

            
            'ijazah_tertinggi' =>
                $validated['ijazah_tertinggi'],

            'ijazah_lainnya' =>
                $validated['ijazah_tertinggi'] === 'Lainnya'
                    ? ($validated['ijazah_lainnya'] ?? null)
                    : null,

            'pekerjaan_utama' =>
                $validated['pekerjaan_utama'],

            'pekerjaan_lainnya' => $validated['pekerjaan_lainnya'] ?? null,

            'status_pekerjaan' =>
                $validated['status_pekerjaan'] ?? null,

            'kepemilikan_rekening' =>
                $validated['kepemilikan_rekening'],

            'is_disabilitas_fisik' =>
                $validated['is_disabilitas_fisik'],

            'is_disabilitas_mental' =>
                $validated['is_disabilitas_mental'],

            'is_disabilitas_intelektual' =>
                $validated['is_disabilitas_intelektual'],

            'is_disabilitas_netra' =>
                $validated['is_disabilitas_netra'],

            'is_disabilitas_rungu' =>
                $validated['is_disabilitas_rungu'],

            'is_disabilitas_wicara' =>
                $validated['is_disabilitas_wicara'],

            'keluhan_kesehatan' => json_encode(
                $validated['keluhan_kesehatan'],
                JSON_UNESCAPED_UNICODE
            ),

            'created_by' =>
                auth()->id() ?? 'system',

            'updated_by' =>
                auth()->id() ?? 'system',

            'updated_at' =>
                now(),
        ];

        /*
        |--------------------------------------------------------------------------
        | UPDATE ATAU INSERT
        |--------------------------------------------------------------------------
        */

        $existing = KeluargaPart5::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )
            ->where(
                'keluarga_anggota_kode',
                $anggota->kode
            )
            ->first();

        if ($existing) {

            $existing->update($data);

        } else {

            $data['created_at'] =
                now();

            KeluargaPart5::create($data);
        }

        return redirect()
            ->route('kuisioner.part5')
            ->with(
                'success',
                'Data anggota berhasil disimpan.'
            );
        }
        
        private function part5DataLengkap($data): bool
        {
            if (!$data) {
                return false;
            }

            $kolomWajib = [
                'keberadaan',
                'jenis_kelamin',
                'status_perkawinan',
                'status_sekolah',
                'ijazah_tertinggi',
                'pekerjaan_utama',
                'kepemilikan_rekening',
                'is_disabilitas_fisik',
                'is_disabilitas_mental',
                'is_disabilitas_intelektual',
                'is_disabilitas_netra',
                'is_disabilitas_rungu',
                'is_disabilitas_wicara',
            ];

            foreach ($kolomWajib as $kolom) {
                if (
                    !isset($data->{$kolom}) ||
                    trim((string) $data->{$kolom}) === ''
                ) {
                    return false;
                }
            }

            if (
                $data->ijazah_tertinggi === 'Lainnya' &&
                trim((string) $data->ijazah_lainnya) === ''
            ) {
                return false;
            }

            if (
                $data->pekerjaan_utama !== 'Tidak Bekerja' &&
                trim((string) $data->status_pekerjaan) === ''
            ) {
                return false;
            }

            $keluhan = $data->keluhan_kesehatan;

            if (is_string($keluhan)) {
                $keluhan = json_decode($keluhan, true);
            }

            if (!is_array($keluhan) || count($keluhan) < 1) {
                return false;
            }

            return true;
        }

    /*
    |--------------------------------------------------------------------------
    | PART 5 FOTO
    |--------------------------------------------------------------------------
    */

    public function part5Foto()
    {
        $keluargaKode = session('selected_keluarga_kode');

        if (!$keluargaKode) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draftId = session('draft_keluarga_id');

        if (!$draftId) {
            return redirect()
                ->route('kuisioner.part1');
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where(
                'keluarga_periode_kode',
                $keluargaKode
            )
            ->where('status', 'draft')
            ->first();

        if (!$draft) {

            session()->forget([
                'draft_keluarga_id',
                'selected_keluarga_kode',
                'part1_selesai',
                'part2_selesai',
                'part3_selesai',
                'part4_selesai',
                'part5_selesai',
            ]);

            return redirect()
                ->route('kuisioner.part1');
        }

        if ((int) $draft->current_part < 5) {
            return redirect()
                ->route('kuisioner.part1');
        }

        /*
        |--------------------------------------------------------------------------
        | TAMPILKAN HALAMAN FOTO
        |--------------------------------------------------------------------------
        */

        /*
        |--------------------------------------------------------------------------
        | CEK KELENGKAPAN PART 5 SEBELUM MEMBUKA HALAMAN FOTO
        |--------------------------------------------------------------------------
        */

        $anggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )->get();

        $dataPart5 = KeluargaPart5::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )->get()->keyBy('keluarga_anggota_kode');

        
        $jumlahAnggota = $anggota->count();

        $statusPart5 = [];

        foreach ($anggota as $item) {
            $data = $dataPart5->get($item->kode);

            $statusPart5[$item->kode] = $data
                ? $this->part5DataLengkap($data)
                : false;
        }

        $jumlahSelesai = count(
            array_filter($statusPart5)
        );

        if ($jumlahAnggota === 0) {
            return redirect()
                ->route('kuisioner.part5')
                ->with(
                    'warning',
                    'Belum ada data anggota keluarga yang tersedia.'
                );
        }

        $fotoRumah = KeluargaFotoRumah::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )
            ->get()
            ->keyBy('jenis_foto');
        
            return view(
            'admin.kuisioner.part5-foto',
            compact('draft', 'fotoRumah')
        );
    }
    /*--------------------------------------------------------------------------
    SIMPAN PART 5 FOTO
    --------------------------------------------------------------------------
    */

    public function storePart5Foto(Request $request)
    {
        /*
        |--------------------------------------------------------------------------
        | AMBIL DRAFT AKTIF
        |--------------------------------------------------------------------------
        */

        $draftId =
            session('draft_keluarga_id');

        if (!$draftId) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'error',
                    'Silakan mulai pengisian kuisioner terlebih dahulu.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | CARI DATA PART 1
        |--------------------------------------------------------------------------
        */

        $draft =
            KeluargaPart1::find($draftId);

        if (!$draft) {

            return redirect()
                ->route('kuisioner.part1')
                ->with(
                    'error',
                    'Data keluarga tidak ditemukan.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | PASTIKAN PART 5
        |--------------------------------------------------------------------------
        */

        if ((int) $draft->current_part < 5) {

            return redirect()
                ->route('kuisioner.part4')
                ->with(
                    'error',
                    'Selesaikan Part 4 terlebih dahulu.'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | CEK KELENGKAPAN ANGGOTA
        |--------------------------------------------------------------------------
        | Foto boleh dibuka walaupun anggota belum lengkap.
        | Tetapi kuisioner tidak boleh berstatus selesai sebelum
        | seluruh anggota keluarga sudah didata.
        |--------------------------------------------------------------------------
        */

        $jumlahAnggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )->count();

        $kodeAnggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )->pluck('kode');

        $dataPart5 = KeluargaPart5::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )
            ->whereIn('keluarga_anggota_kode', $kodeAnggota)
            ->get()
            ->keyBy('keluarga_anggota_kode');

        $jumlahAnggotaSelesai = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )->get()->filter(function ($item) use ($dataPart5) {
            $data = $dataPart5->get($item->kode);

            return $data && $this->part5DataLengkap($data);
        })->count();

        $semuaAnggotaSelesai =
            $jumlahAnggota > 0 &&
            $jumlahAnggota === $jumlahAnggotaSelesai;

        /*
        |--------------------------------------------------------------------------
        | VALIDASI FOTO
        |--------------------------------------------------------------------------
        */

        
        $action = $request->input('action', 'final');
        $isDraft = $action === 'draft';
        $deleteFoto = $request->input('delete_foto', []);

        $fotoTersimpan = KeluargaFotoRumah::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )->get()->keyBy('jenis_foto');

        $aturanFoto = [];

        foreach (['tampak_depan', 'ruang_tamu', 'kamar_mandi'] as $field) {
            $fotoLamaAda = $fotoTersimpan->has($field);
            $ditandaiHapus = !empty($deleteFoto[$field]);

            $wajibUpload = !$isDraft && (
                !$fotoLamaAda || $ditandaiHapus
            );

            $aturanFoto[$field] = [
                $wajibUpload ? 'required' : 'nullable',
                'image',
                'mimes:jpg,jpeg,png',
                'max:5120',
            ];
        }

        $request->validate($aturanFoto, [
            'tampak_depan.required' =>
                'Foto tampak depan wajib diupload.',
            'ruang_tamu.required' =>
                'Foto ruang tamu wajib diupload.',
            'kamar_mandi.required' =>
                'Foto kamar mandi wajib diupload.',
            '*.image' =>
                'File harus berupa gambar.',
            '*.mimes' =>
                'Format foto harus JPG, JPEG, atau PNG.',
            '*.max' =>
                'Ukuran setiap foto maksimal 5 MB.',
        ]);

        /*
        |--------------------------------------------------------------------------
        | JENIS FOTO
        |--------------------------------------------------------------------------
        */

        $jenisFoto = [

            'tampak_depan' =>
                'Foto Tampak Depan',

            'ruang_tamu' =>
                'Foto Ruang Tamu',

            'kamar_mandi' =>
                'Foto Kamar Mandi',
        ];

        /*
        |--------------------------------------------------------------------------
        | USER
        |--------------------------------------------------------------------------
        */

        $user = auth()->user();

        $userName = $user
            ? (
                $user->name
                ?? $user->username
                ?? 'admin'
            )
            : 'admin';

        $userId =
            auth()->id() ?? 'system';

        /*
        |--------------------------------------------------------------------------
        | SIMPAN FOTO + SELESAIKAN KUISIONER
        |--------------------------------------------------------------------------
        */

        DB::beginTransaction();

        try {

            foreach ($jenisFoto as $field => $namaJenis) {
                $file = $request->file($field);
                $markedDelete = !empty($deleteFoto[$field]);

                $existing = KeluargaFotoRumah::where(
                    'keluarga_periode_kode',
                    $draft->keluarga_periode_kode
                )
                    ->where('jenis_foto', $field)
                    ->first();

                if ($markedDelete && !$file) {
                    if ($existing) {
                        $pathLama = $existing->path_file;

                        $existing->delete();

                        if ($pathLama) {
                            Storage::disk('public')->delete($pathLama);
                        }
                    }

                    continue;
                }

                if (!$file) {
                    continue;
                }

                $namaFile = time()
                    . '_'
                    . $field
                    . '_'
                    . uniqid()
                    . '.'
                    . $file->getClientOriginalExtension();

                $path = $file->storeAs(
                    'kuisioner/rumah',
                    $namaFile,
                    'public'
                );

                if (!$path) {
                    throw new \RuntimeException(
                        'Gagal menyimpan foto ' . $namaJenis . '.'
                    );
                }

                $data = [
                    'keluarga_periode_kode' => $draft->keluarga_periode_kode,
                    'jenis_foto' => $field,
                    'nama_file' => $namaFile,
                    'path_file' => $path,
                    'updated_by' => $userId,
                    'updated_at' => now(),
                ];

                if ($existing) {
                    $pathLama = $existing->path_file;

                    $existing->update($data);

                    if ($pathLama && $pathLama !== $path) {
                        Storage::disk('public')->delete($pathLama);
                    }
                } else {
                    $data['created_by'] = $userId;
                    $data['created_at'] = now();

                    KeluargaFotoRumah::create($data);
                }
            }

            if ($isDraft) {

                $draft->update([
                    'status' => 'draft',
                    'current_part' => 5,
                    'updated_by' => $userName,
                    'updated_at' => now(),
                ]);

                DB::commit();

                return redirect()
                    ->route('kuisioner.index')
                    ->with(
                        'success',
                        'Foto rumah berhasil disimpan sebagai draft.'
                    );
            }

            /*
            |--------------------------------------------------------------------------
            | JIKA ANGGOTA BELUM LENGKAP, TETAP DRAFT
            |--------------------------------------------------------------------------
            */

            if (!$semuaAnggotaSelesai) {

                DB::commit();

                return redirect()
                    ->route('kuisioner.part5')
                    ->with(
                        'warning',
                        'Foto rumah tersimpan, tetapi kuisioner belum dapat diselesaikan karena masih ada anggota keluarga yang belum didata.'
                    );
            }

            /*
            |--------------------------------------------------------------------------
            | UBAH STATUS DRAFT MENJADI SELESAI
            |--------------------------------------------------------------------------
            */

            $draft->update([

                'status' =>
                    'selesai',

                'current_part' =>
                    5,

                'updated_by' =>
                    $userName,

                'updated_at' =>
                    now(),
            ]);

            /*
            |--------------------------------------------------------------------------
            | BERSIHKAN SESSION
            |--------------------------------------------------------------------------
            */

            session()->forget([

                'draft_keluarga_id',

                'selected_keluarga_kode',

                'part1_selesai',

                'part2_selesai',

                'part3_selesai',

                'part4_selesai',

                'part5_selesai',
            ]);

            DB::commit();

            /*
            |--------------------------------------------------------------------------
            | REDIRECT
            |--------------------------------------------------------------------------
            */

            return redirect()
                ->route('kuisioner.selesai')
                ->with(
                    'success',
                    'Foto rumah berhasil disimpan. Kuisioner selesai.'
                );

        } catch (\Throwable $e) {

            DB::rollBack();

            return back()
                ->withInput()
                ->with(
                    'error',
                    'Kuisioner gagal diselesaikan: ' .
                    $e->getMessage()
                );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | SELESAI KUISIONER
    |--------------------------------------------------------------------------
    */

    public function selesaiKuisioner(Request $request)
    {
        $draftId =
            session('draft_keluarga_id');

        if (!$draftId) {

            return redirect()
                ->route('kuisioner.index')
                ->with(
                    'warning',
                    'Tidak ada kuisioner aktif.'
                );
        }

        $draft =
            KeluargaPart1::findOrFail($draftId);

        $jumlahAnggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )->count();

        $kodeAnggota = KeluargaAnggota::where(
            'keluarga_kode',
            $draft->keluarga_periode_kode
        )->pluck('kode');

        $jumlahAnggotaTerdata = KeluargaPart5::where(
            'keluarga_periode_kode',
            $draft->keluarga_periode_kode
        )
            ->whereIn('keluarga_anggota_kode', $kodeAnggota)
            ->count();

        if ($jumlahAnggota === 0 || $jumlahAnggotaTerdata < $jumlahAnggota) {
            return redirect()
                ->route('kuisioner.part5')
                ->with(
                    'warning',
                    'Kuisioner belum dapat diselesaikan karena masih ada anggota keluarga yang belum didata.'
                );
        }

        $draft->update([

            'status' =>
                'selesai',

            'current_part' =>
                5,

            'updated_by' =>
                auth()->user()->name ?? 'admin',
        ]);

        session()->forget([

            'draft_keluarga_id',

            'selected_keluarga_kode',

            'part1_selesai',

            'part2_selesai',

            'part3_selesai',

            'part4_selesai',

            'part5_selesai',
        ]);

        return redirect()
            ->route('kuisioner.selesai')
            ->with(
                'success',
                'Kuisioner berhasil diselesaikan.'
            );
    }

    /*
    |--------------------------------------------------------------------------
    | DETAIL KUISIONER SELESAI
    |--------------------------------------------------------------------------
    */

    public function detailSelesai($id)
    {
        $dataPart1 = KeluargaPart1::findOrFail($id);

        if ($dataPart1->status !== 'selesai') {
            return redirect()
                ->route('kuisioner.selesai')
                ->with('warning', 'Data kuisioner belum berstatus selesai.');
        }

        $keluargaKode = $dataPart1->keluarga_periode_kode;

        $keluarga = Keluarga::where('kode', $keluargaKode)->first();
        if (!$keluarga && $dataPart1->no_kk) {
            $keluarga = Keluarga::where('no_kk', $dataPart1->no_kk)->first();
        }

        // Ambil nilai pertama yang benar-benar terisi, bukan sekadar tidak-null.
        $firstFilled = static function (...$values) {
            foreach ($values as $value) {
                if (is_string($value)) {
                    $value = trim($value);
                }
                if ($value !== null && $value !== '') {
                    return $value;
                }
            }
            return null;
        };

        // Jumlah anggota: utamakan jawaban Part 1, lalu hitung data anggota.
        // Kode anggota keluarga mengacu pada kode keluarga, bukan kode periode.
        $kodeUntukAnggota = $keluarga->kode ?? $keluargaKode;
        $jumlahAnggotaTambahan = $kodeUntukAnggota
            ? KeluargaAnggota::where('keluarga_kode', $kodeUntukAnggota)->count()
            : 0;
        $jumlahKeluarga = $firstFilled(
            $dataPart1->jml_keluarga,
            $dataPart1->jumlah_keluarga,
            $dataPart1->jumlah_anggota_keluarga,
            $keluarga->jumlah_anggota_keluarga ?? null,
            $keluarga->jml_keluarga ?? null
        );
        // Jika jumlah tidak diisi langsung, gunakan jumlah kepala keluarga + anggota tambahan.
        if ($jumlahKeluarga === null && ($keluarga || $jumlahAnggotaTambahan > 0)) {
            // Kepala keluarga + anggota tambahan yang tersimpan pada tabel keluarga_anggotas.
            $jumlahKeluarga = 1 + $jumlahAnggotaTambahan;
        }
        $dataPart1->jumlah_keluarga_display = $jumlahKeluarga ?? '-';

        // Nama kecamatan/kelurahan dari jawaban Part 1, atau lookup dari master wilayah.
        $namaKecamatan = $firstFilled($dataPart1->kecamatan, $keluarga->kecamatan ?? null);
        if (!$namaKecamatan && $keluarga && $keluarga->kecamatan_id) {
            $namaKecamatan = DB::table('kecamatans')
                ->where('kecamatan_id', $keluarga->kecamatan_id)
                ->value('deskripsi');
        }
        $namaKelurahan = $firstFilled($dataPart1->kelurahan, $dataPart1->desa ?? null, $keluarga->kelurahan ?? null);
        if (!$namaKelurahan && $keluarga && $keluarga->kelurahan_id) {
            $namaKelurahan = DB::table('kelurahans')
                ->where('kelurahan_id', $keluarga->kelurahan_id)
                ->value('deskripsi');
        }

        // RT/RW pada form Part 1 disimpan dalam satu kolom rt_rw.
        $rtRw = $firstFilled($dataPart1->rt_rw, $keluarga->rt_rw ?? null);
        if (!$rtRw) {
            $rt = $firstFilled($keluarga->rt ?? null);
            $rw = $firstFilled($keluarga->rw ?? null);
            $rtRw = ($rt || $rw) ? trim(($rt ?? '-') . ' / ' . ($rw ?? '-')) : null;
        }

        $provinsi = $firstFilled($dataPart1->provinsi, $keluarga->provinsi ?? null);
        // Tabel keluargas tidak memiliki kolom daerah; gunakan jawaban Part 1,
        // lalu default Kota Pasuruan jika jawaban tersebut kosong.
        $daerah = $firstFilled(
            $dataPart1->daerah,
            'Kota Pasuruan'
        );
        $alamatLengkap = $firstFilled(
            $dataPart1->alamat_lengkap,
            $keluarga->alamat_lengkap ?? null,
            $keluarga->alamat ?? null
        );
        $geotagging = $firstFilled(
            $dataPart1->geotangging,
            $keluarga->geotagging ?? null,
            $keluarga->geotangging ?? null
        );

        $dataPart1->provinsi_display = $provinsi ?? '-';
        $dataPart1->daerah_display = $daerah ?? '-';
        $dataPart1->kecamatan_display = $namaKecamatan ?? '-';
        $dataPart1->kelurahan_display = $namaKelurahan ?? '-';
        $dataPart1->rt_rw_display = $rtRw ?? '-';
        $dataPart1->alamat_lengkap_display = $alamatLengkap ?? '-';
        $dataPart1->geotagging_display = $geotagging ?? '-';
        $dataPart1->kota_kabupaten_display = $daerah ?? 'Kota Pasuruan';

        $dataPart2 = KeluargaPart2::where('keluarga_periode_kode', $keluargaKode)->first();
        $dataPart3 = KeluargaPart3::where('keluarga_periode_kode', $keluargaKode)->first();
        $dataPart4 = KeluargaPart4::where('keluarga_periode_kode', $keluargaKode)->get();
        $anggota = KeluargaAnggota::where('keluarga_kode', $keluargaKode)
            ->orderBy('id')
            ->get();
        $dataPart5 = KeluargaPart5::where('keluarga_periode_kode', $keluargaKode)
            ->get()
            ->keyBy('keluarga_anggota_kode');
        $fotoRumah = KeluargaFotoRumah::where('keluarga_periode_kode', $keluargaKode)
            ->get()
            ->keyBy('jenis_foto');

        return view(
            'admin.kuisioner.detail-selesai',
            compact(
                'dataPart1',
                'dataPart2',
                'dataPart3',
                'dataPart4',
                'anggota',
                'dataPart5',
                'fotoRumah',
                'keluarga'
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | RESUME DRAFT
    |--------------------------------------------------------------------------
    */

    public function resumeDraft($id)
    {
        $draft = KeluargaPart1::where(
            'id',
            $id
        )
            ->where(
                'status',
                'draft'
            )
            ->firstOrFail();

        session([

            'draft_keluarga_id' =>
                $draft->id,

            'selected_keluarga_kode' =>
                $draft->keluarga_periode_kode,

            'part1_selesai' =>
                (int) $draft->current_part >= 2,

            'part2_selesai' =>
                (int) $draft->current_part >= 3,

            'part3_selesai' =>
                (int) $draft->current_part >= 4,

            'part4_selesai' =>
                (int) $draft->current_part >= 5,

            'part5_selesai' =>
                false,
        ]);

        switch (
            (int) $draft->current_part
        ) {

            case 1:

                return redirect()
                    ->route(
                        'kuisioner.part1'
                    );

            case 2:

                return redirect()
                    ->route(
                        'kuisioner.part2'
                    );

            case 3:

                return redirect()
                    ->route(
                        'kuisioner.part3'
                    );

            case 4:

                return redirect()
                    ->route(
                        'kuisioner.part4'
                    );

            case 5:

                return redirect()
                    ->route(
                        'kuisioner.part5.foto'
                    );

            default:

                return redirect()
                    ->route(
                        'kuisioner.part1'
                    );
        }
    }
    
    
    public function simpanDraftPart5()
    {
        $draftId = session('draft_keluarga_id');
        $keluargaKode = session('selected_keluarga_kode');

        if (!$draftId || !$keluargaKode) {
            return redirect()
                ->route('kuisioner.part1')
                ->with('error', 'Sesi draft tidak ditemukan. Silakan buka kembali draft keluarga.');
        }

        $draft = KeluargaPart1::where('id', $draftId)
            ->where('keluarga_periode_kode', $keluargaKode)
            ->where('status', 'draft')
            ->first();

        if (!$draft) {
            return redirect()
                ->route('kuisioner.index')
                ->with('error', 'Draft tidak ditemukan atau sudah selesai.');
        }

        // Simpan posisi terakhir di Part 5.
        $draft->current_part = 5;
        $draft->updated_by = auth()->user()->username
            ?? auth()->user()->name
            ?? 'admin';
        $draft->save();

        // Kembali ke halaman daftar draft agar hasilnya terlihat.
        return redirect()
            ->route('kuisioner.index')
            ->with('success', 'Draft Part 5 berhasil disimpan. Kamu bisa melanjutkan pengisian nanti.');
    }
   


}